# ChatGPT DOM Extension #
Written by 'Doc' Tomiko Carpe 2026
Learn more at https://doctorwyrm.com

## A Quick Summary of What This Extension Does ##
Right now, this extension crawls the visible page content in ChatGPT and captures a data-structure of whatever chat is on the web-page currently loaded. It undersatands how React works and deals with that, including partially loading / streaming Assistant responses.

It can also theoretically be used to place text into the input field textbox and simulate pressing Send when explicitly instructed, but so far nothing calls that yet - and when it does it will have a safety switches added, trust me on this.

The extension has hotkeys to let you export the current chat thread. You can do JSON, MarkDown, or HTML. Or you can use the backup features (auto, on-load, and manual) to seamlessly make local copies of your chats in all the formats that you desire.

### Some Additional Comments ###
I did not implement PDF because that usually means a third-party provider and I respect your privacy. This extension does not send any of your chat data to me or anybody else - only your downloads folder.

Yes, I am aware that you can export all your data from ChatGPT settings menu. I have a few commetns about that. Firstly, it takes 24 hours. Second, you have to click the link they send in email or it will expire. I cannot tell you how many times I have lost track of time and forgotten to do this. Plus, the format they send, though complete, is mostly like the JSON export in this extension. I wanted to provide users some human readable options. **I still believe this extension is useful, because it works in real-time and does not depend on OpenAI following the laws or being kind.**

## How To Use It ##
**ONLY** works at ChatGpt.com, nowhere else.
On non-chat-thread pages, it should do nothing at all.

There's no configuration UI yet. It's only 2 days old - if that. Sorry for being slow about that.

Here are the default (soon to be mappable) hot-keys:
* **Ctrl+Shift+K** - Keyboard overlay to remind you what the hotkeys are.
* **Ctrl+Shift+S** - (S)ave as JSON data. Please do not send me emails asking why I couldn't use Ctrl+Shift+J, because if you don't know then you're obviously not a web developer. ^_^
* **Ctrl+Shift+M** - Save as MarkDown file.
* **Ctrl+Shift+H** - Save as single file HTML
* **Ctrl+Shift+A** - Toggles Auto-backup of every chat. Currently the default is every 30 messages (15 interactions between you and the chatbot). The default is JSON, but this will be configurable later.
* **Ctrl+Shift+L** - Toggles Backup On Load, which is useful if you want to click through a lot of saved chats and save them without user interaction. The current default in the config file is JSON, but the others are possible with a configuration layer.
* **Ctrl+Shift+B** - Explicitly (B)ackup this chat session right now, based on what is currently present. Same defaults apply as for On-load backup.

---

## What This Extension Does (and Does Not Do) - A Detailed Explanation
This extension is a **local, user-controlled tool** for interacting with ChatGPT conversations in the browser.

### What It DOES Do

- Runs **only** on pages under `https://chatgpt.com/`
- Reads the **visible page content** of the current chat page
- Extracts conversation messages for:
  - JSON export
  - Markdown export
  - HTML export
- Can automatically back up conversations as they complete (optional)
- Stores configuration **locally in the browser** (no network sync)

- Can place text into the chat input box text field on user command (future features)
- Can simulate pressing Send when explicitly instructed (future features)
- Requires **no external services** to function (see Future Improvements Planned)

All actions are initiated by:
- explicit hotkeys, or
- explicit configuration settings chosen by the user

Nothing runs silently or without consent.

---

### What It DOES NOT Do

- Does **not** send your data anywhere
- Does **not** read cookies, tokens, or account information
- Does **not** access ChatGPT APIs
- Does **not** bypass rate limits, paywalls, or safeguards
- Does **not** record keystrokes outside the ChatGPT page
- Does **not** modify server-side behavior
- Does **not** make network requests of any kind (in this version)
- Does **not** automate conversations on its own (in this version)

This extension only observes and interacts with what is already rendered in your browser.

---

### Privacy & Safety Notes

- All processing happens locally in your browser
- Exported files are saved by your browser’s normal download mechanism
- Configuration is stored via browser extension storage or localStorage
- Removing the extension removes all functionality immediately

If you don’t press a key or enable a feature, nothing happens.

---

### Intended Audience

This tool is intended for:
- developers
- researchers
- writers
- power users
- archivists

It is **not** designed for unattended automation or mass scraping.

If you’re unsure what a feature does, leave it disabled.

---

### Status

This extension is under **active development**.
APIs, hotkeys, and configuration options may change.

Use at your own discretion, and please review the source before installing.

---

### Future Improvements Planned
We want to make sure older chats are fully captured. Scroll-up is not implemented yet, so be advised you may not get a complete backup of all messages in very lengthy or older chats. It was tested with 200 messages on a chat that remained open and was recent.

We intend to add capability to stream messages to a web service. This would be a locally hosted (e.g. on your PC, Docker container, private server, etc.) service, not some BS in the cloud meant to capture all your chats. It will be configurable.

Once we have streaming service working, we will also allow that service to send messages back to your chat window. This is meant for integrations, not spamming your chat. Think 'IFTTT can send messages to your chatbot at your discretion', as long as you have a browser open and pointing to an active chat window.

Longer term, these integrations would potentially allow you to chat with your bot in let's say a Discord channel on a server that you configure - where other people could see it, and potentially participate in conversations with you. This will be configurable, and would require installing a Discord bot, and having a guild you can point it to. In no way would we enforce that anyone implements such a use-case, but I wanted to disclose that future versions may have the wiring to do such things.




