const api = typeof browser !== "undefined" ? browser : chrome;

const STORAGE_KEY = "chatgptdom.config";
const SCHEMA_VERSION = 1;

const DEFAULT_CONFIG = {
  schema_version: SCHEMA_VERSION,
  exportConfig: {
    autoBackup: {
      enabled: false,
      formats: ["json"],
      everyNMessages: 10,
    },
    backupOnLoad: {
      enabled: false,
      formats: ["json"],
    },
    toastOnExport: true
  },
  keyBindings: {
    exportJSON: "Ctrl+Shift+S",
    exportMD: "Ctrl+Shift+M",
    exportHTML: "Ctrl+Shift+H",
    toggleAutoBackup: "Ctrl+Shift+B",
    toggleBackupOnLoad: "Ctrl+Shift+L",
    manualFullBackup: "Ctrl+Shift+F",
    showKeyBindings: "Ctrl+Shift+K"
  }};
  const knownBrowserShortcuts = new Set([
    "Ctrl+T",
    "Ctrl+W",
    "Ctrl+Shift+T",
    "Ctrl+L",
    "Ctrl+Tab",
    "Ctrl+Shift+Tab",
    "Ctrl+R",
    "Ctrl+Shift+R",
    "Ctrl+N",
    "Ctrl+Shift+N",
    "Ctrl+J",
    "Ctrl+K",
    "Ctrl+F",
    "Ctrl+H"
  ]);

async function ensureDefaults() {
  const existing = await api.storage.local.get("config");
  if (!existing.config) {
    await api.storage.local.set({ config: DEFAULT_CONFIG });
  }
}

async function getConfig() {
  const result = await api.storage.local.get(STORAGE_KEY);
  const stored = result[STORAGE_KEY];

  if (!stored || stored.schema_version !== SCHEMA_VERSION) {
    await api.storage.local.set({ [STORAGE_KEY]: DEFAULT_CONFIG });
    return structuredClone(DEFAULT_CONFIG);
  }
  return stored;
}
async function setConfig(newConfig) {
  await api.storage.local.set({ [STORAGE_KEY]: newConfig });
  return { ok: true };
}

function detectConflicts(keyBindings) {
  const combos = Object.values(keyBindings || {}).map(k => k.combo);
  const seen = new Set();
  const conflicts = [];

  for (const combo of combos) {
    if (!combo) continue;

    if (knownBrowserShortcuts.has(combo)) {
      conflicts.push({
        combo,
        type: "browser"
      });
    }

    if (seen.has(combo)) {
      conflicts.push({
        combo,
        type: "duplicate"
      });
    }

    seen.add(combo);
  }

  return conflicts;
}

async function broadcastConfigUpdate() {
  const cfg = await getConfig();
  const tabs = await api.tabs.query({});
  for (const tab of tabs) {
    api.tabs.sendMessage(tab.id, { type: "CONFIG_UPDATED", payload: cfg })
      .catch(() => {});
  }
}

api.runtime.onInstalled.addListener(async () => {
  getConfig().then(result => {
    sendResponse(result);
  });
  console.log("[ChatGPTDOM] Initialized with defaults if needed");
  return true; // ← REQUIRED in MV3  }
});

api.runtime.onMessage.addListener((message) => {
  if (!message?.type) return;
  if (message.type === "GET_CONFIG") {
    getConfig().then(result => {
      sendResponse(result);
    });
    return true; // ← REQUIRED in MV3  
  }
  if (message.type === "SET_CONFIG") {
    setConfig(message.payload).then(async () => {
        await broadcastConfigUpdate();
        sendResponse({ ok: true });
    });
    return true; // ← REQUIRED in MV3
  }
  if (message.type === "RESET_CONFIG") {
    api.storage.local
      .set({ [STORAGE_KEY]: DEFAULT_CONFIG })
      .then(async () => {
      await broadcastConfigUpdate().then(() => {
        console.log("[ChatGPTDOM] Config reset to defaults and update broadcasted");
        sendResponse(structuredClone(DEFAULT_CONFIG));
      });
      return true; // ← REQUIRED in MV3
    });
  }
  if (message.type === "CHECK_CONFLICTS") {
    sendResponse(Promise.resolve({
      conflicts: detectConflicts(message.payload)
    }));
    return true; // ← REQUIRED in MV3
  }  
});

ensureDefaults();