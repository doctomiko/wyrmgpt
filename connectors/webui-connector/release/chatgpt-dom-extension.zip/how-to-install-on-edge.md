# How to Install the ChatGPT DOM Adapter Extension on Microsoft Edge

This guide explains how to install the extension in **Developer Mode** on Microsoft Edge.  
No store account, no signing, no magic — just load the folder.

---

## What You Need

Unzip the extension file into a folder on the PC with your browser. Make sure you put it in a location that will persist, not some subfolder of your Downloads folder. Edge requires the files to stay in place.

You should have a folder that contains at least:

- `manifest.json`
- `content.js`
- `icon.png` or similar file
- maybe some markdown files like README.md and stuff
- possible some HTML files for the settings UI.

All of these are free for you to inspect and assure yourself the extension is safe to use.

⚠️ **Important:**  
You must unzip the extension first. Edge cannot load extensions directly from a ZIP file.

---

## Step-by-Step Installation

### 1. Unzip the Extension

- Extract the ZIP file to a permanent location  
  (e.g. Documents, Projects, Desktop — anywhere you won’t delete it)

⚠️ **Important:**
Edge requires the folder to stay in place. If you move or delete it later, the extension will be disabled.

---

### 2. Open the Extensions Page

- Open Microsoft Edge
- In the address bar, go to: "edge://extensions"
  Or click "..." in upper-right corner > Extensions.

---

### 3. Enable Developer Mode

Edge hides this slightly:

1. Look at the **top-left corner** of the page
2. Click the **☰ (hamburger menu)** to open the sidebar (if it isn’t already visible)
3. At the **bottom of the left sidebar**, toggle **Developer mode** to **ON**

Once enabled, new buttons will appear in the main panel.

---

### 4. Load the Extension

1. Click **Load unpacked**
2. Select the **folder** that contains `manifest.json`
3. Click **Select Folder**

If everything is correct, the extension will load immediately.

---

## Confirm It Worked

You should now see:

- The extension listed by name
- An on/off toggle (leave it ON)
- The extension icon (if provided)

Open a new tab and go to: https://chatgpt.com

Use the chatbot as you normally would.
The extension will run automatically on matching pages.

⚠️ **Important:**
You will need to use the hotkeys to enable auto-backup.
See README.md file for instructions on default hot key settings, or hit Ctrl+Shift+K to see a quick display.

---

## Notes & Caveats

- This is a **developer install**
- The extension will **not auto-update**
- The extension stays installed across browser restarts
- To uninstall: disable it or remove the folder and reload Edge

Nothing runs unless the extension is enabled.

---

## Troubleshooting

- **No “Load unpacked” button?**  
  Developer Mode is not enabled — recheck the sidebar toggle.

- **Extension disappears after restart?**  
  The folder was moved or deleted.

- **Nothing seems to happen?**  
  Open DevTools on `chatgpt.com` and check the Console for logs.

---

That’s it. You’re done.





